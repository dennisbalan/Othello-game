package com.example.othello40

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.view.GestureDetectorCompat

class NewView (context: Context, attrs: AttributeSet?) : View(context,attrs), GestureDetector.OnGestureListener {
    private var mDetector = GestureDetectorCompat(this.context, this)
    private var squareColor = Color.GREEN
    private var height = 0.0f
    private var width = 0.0f
    private var tenWidth = 0.0f
    private var tenHeight = 0.0f
    private var ten = 0.0f
    private var smallest = 0.0f
    private var array = arrayOf<Array<Int>>()
    private var current = 1
    private var waiting = 2
    private var GameOver = 0
    private var win1 = 0
    private var win2 = 0
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        height = h.toFloat()
        width = w.toFloat()
        if (height > width) {
            smallest = width
            ten = width / 10
        }
        if (width > height) {
            smallest = height
            ten = height / 10
        }
        for (i in 0..9) {
            var temp = arrayOf<Int>()
            for (j in 0..9) {
                temp += 0
            }
            array += temp
        }
        array[3][3] = 1
        array[4][4] = 1
        array[4][3] = 2
        array[3][4] = 2
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (mDetector.onTouchEvent(event)) {
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint = Paint()
        paint.color = squareColor
        for (i in 0..8) {
            canvas.drawLine(0.0f, i * ten, smallest, i * ten, paint)
            canvas.drawLine(i * ten, smallest, i * ten, 0.0f, paint)
        }
        for (i in 0..8) {
            for (j in 0..8) {
                if(array[j][i] == 0){
                    paint.color = Color.YELLOW
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawText("0",(j+1) * ten - (ten/2f),(i+1) * ten - (ten/4f),paint)
                }
                if (array[j][i] == 1) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawText(
                        "1",
                        (j + 1) * ten - (ten / 2f),
                        (i + 1) * ten - (ten / 4f),
                        paint
                    )
                }
                if (array[j][i] == 2) {
                    paint.color = Color.BLUE
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawText(
                        "2",
                        (j + 1) * ten - (ten / 2f),
                        (i + 1) * ten - (ten / 4f),
                        paint
                    )
                }
            }
        }
        if(width < height) {
            paint.color = Color.RED
            paint.textSize = 50f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("Player", (1 * ten), (11 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(current.toString(), (1 * ten), (12 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 1", (3 * ten), (11 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(1).toString(), (3 * ten), (12 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 2", (5 * ten), (11 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(2).toString(), (5 * ten), (12 * ten), paint)
            canvas.drawText("Reset", 7 * ten, 12 * ten, paint)
        }
        if(height < width){
            paint.color = Color.RED
            paint.textSize = 50f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("Player", (11 * ten), (1 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(current.toString(), (12 * ten), (1 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 1", (11 * ten), (3 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(1).toString(), (12 * ten), (3 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 2", (11 * ten), (5 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(2).toString(), (12 * ten), (5 * ten), paint)
            canvas.drawText("Reset", 12 * ten, 7 * ten, paint)
        }
    }

    override fun onDown(p0: MotionEvent?): Boolean {
        return true
    }

    override fun onShowPress(p0: MotionEvent?) {
    }

    override fun onSingleTapUp(p0: MotionEvent?): Boolean {
        var x_value = 0
        var y_value = 0
        if (p0 != null) {
            if(p0.y > (11 * ten) && p0.y < (12 * ten)){
                Log.d("String",(p0.y).toString() + " " + (12 * ten).toString())
                if(p0.x > (6 * ten)  && p0.x < (8 * ten)){
                    for (i in 0..9) {
                        for(j in 0..9){
                            array[i][j] = 0
                        }
                    }
                    array[3][3] = 1
                    array[4][4] = 1
                    array[4][3] = 2
                    array[3][4] = 2
                    Log.d("ibc","inval")
                }
            }
            for (i in 0..8) {
                    if ((p0.x >= (i * ten)) && (p0.x <= ((i + 1) * ten))) {
                        x_value = i
                    }
                    if (p0.y >= (i * ten) && p0.y <= ((i + 1)) * ten) {
                        y_value = i
                    }
                }


        }
        Log.d("X-Value - 1",x_value.toString())
        for (j in -1..2) {
            Log.d("J",j.toString())
            for (k in -1..2) {
                if((x_value == 0 && j == -1) || (x_value == 8 && (j == 1) || j == 2 ) || (y_value == 0 && k == -1) || (y_value == 8 && k == 1)){
                    Log.d("Skip", "skip")
                    Log.d("j,K",j.toString() + " " + k.toString())

                }
                else{
                    Log.d("X,Y",x_value.toString() + " " + y_value.toString())
                    testCells(x_value, y_value, j, k, 1)}


            }


        }
        for(l in -1..2){
            GameOver = 1
            for(k in -1 .. 2){
                if((x_value == 0 && k == -1) || (x_value == 8 && k == 1) || (y_value == 0 && k == -1) || (y_value == 8 && k == 1)){
                    Log.d("Skip", "skip")
                }
                else{testCells(x_value,y_value,l,k,0)}
            }
            if(GameOver == 1){

            }
        }
        invalidate()
        return true
    }

    override fun onLongPress(p0: MotionEvent?) {
    }

    override fun onScroll(p0: MotionEvent?, p1: MotionEvent?, p2: Float, p3: Float): Boolean {
        return false
    }

    override fun onFling(p0: MotionEvent?, p1: MotionEvent?, p2: Float, p3: Float): Boolean{
        return false
    }

    private fun testCells(x_value: Int, y_value: Int,i: Int, j: Int,replace:Int) {
        if (array[x_value+ i][y_value + j] == waiting) {
            Log.d("X,y",x_value.toString() + " " + y_value.toString())
            if (array[x_value + i + i][y_value + j + j] == current) {
                if(replace == 1) {
                    array[x_value + i][y_value + j] = current
                    array[x_value][y_value] = current

                    val temp = current
                    current = waiting
                    waiting = temp
                }
                if(replace == 0){
                    GameOver = 0
                    if(waiting == 1){

                    }
                }
            }
        }
    }
    private fun Score(a : Int) : Int{
        var b = 0
        for(i in 0..8){
            for(j in 0..8){
                if(array[j][i] == a){
                    b = b + 1
                }
            }
        }
        return b
    }

}
